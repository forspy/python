from setuptools import setup
setup(
    name='testlib1',
    version='1.0',
    description='创建库',
    author='qbw',
    author_email='test@126.com',
    url='创建者网址(选填)',
    py_modules=['testFun'],
)